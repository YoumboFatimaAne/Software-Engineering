"""
Wizard Duel - the computer opponent.

The computer plays by the same rules as a person: every frame it decides which
actions to "hold" (left, right, jump, block, attack, spell1, spell2), and the
game turns those into key presses. Difficulty only changes how quickly and how
well it reacts, never its wizard's stats.
"""
import random

# think:       frames between decisions (lower = sharper)
# react:       chance of noticing an incoming spell in time
# block:       chance of blocking (vs. jumping) when it does react, and of
#              blocking a wand strike up close
# aggro:       chance of attacking when an attack is ready
# range_slop:  how loosely it keeps its preferred distance, in pixels
DIFFICULTIES = {
    "Easy":   {"think": 16, "react": 0.40, "block": 0.30, "aggro": 0.60, "range_slop": 100},
    "Normal": {"think": 11, "react": 0.65, "block": 0.55, "aggro": 0.70, "range_slop": 60},
    "Hard":   {"think": 5,  "react": 0.92, "block": 0.85, "aggro": 0.90, "range_slop": 25},
}
LEVELS = list(DIFFICULTIES)

# Distance (centre to centre) each signature spell likes to fight from
PREFERRED_RANGE = {"fire": 300, "vines": 280, "volley": 260, "quake": 230}
MELEE_GAP = 55            # space between bodies at which a wand strike can land
SPELL_WARNING = 230       # how far away an incoming spell gets noticed


class ComputerPlayer:
    def __init__(self, difficulty="Normal", arena_width=960, rng=None):
        self.difficulty = difficulty
        self.level = DIFFICULTIES[difficulty]
        self.arena_width = arena_width
        self.rng = rng or random.Random()
        self.timer = 0
        self.move = 0             # -1 left, 0 stay, 1 right
        self.hold = {}            # action -> frames left to hold it
        self.seen = set()         # spells already reacted to

    def press(self, action, frames=1):
        self.hold[action] = max(self.hold.get(action, 0), frames)

    def update(self, me, foe, projectiles):
        """Return the set of actions to hold this frame."""
        lv, r = self.level, self.rng

        # 1. Watch for incoming spells every frame (each one is judged once)
        live = set()
        for p in projectiles:
            live.add(id(p))
            if p.owner is me or id(p) in self.seen:
                continue
            distance = (me.rect.centerx - p.x) * p.dir     # > 0 while it flies toward me
            if 0 < distance < SPELL_WARNING:
                self.seen.add(id(p))
                if r.random() < lv["react"]:
                    if p.kind == "quake" or r.random() >= lv["block"]:
                        self.press("jump", 4)              # Shockwave can only be jumped
                    else:
                        self.press("block", int(distance / p.speed) + 8)
        self.seen &= live

        # 2. Re-plan every few frames
        self.timer -= 1
        if self.timer <= 0:
            self.timer = lv["think"] + r.randint(0, lv["think"] // 2)
            self.plan(me, foe)

        # 3. Turn the plan into held actions
        held = {a for a, frames in self.hold.items() if frames > 0}
        for a in self.hold:
            self.hold[a] -= 1
        if "block" not in held:
            if self.move < 0:
                held.add("left")
            elif self.move > 0:
                held.add("right")
        return held

    def plan(self, me, foe):
        lv, r = self.level, self.rng
        dx = foe.rect.centerx - me.rect.centerx
        toward = 1 if dx > 0 else -1
        distance = abs(dx)
        gap = distance - me.rect.width
        kind = me.spell("spell2")["kind"]

        # Up close: block a strike that is coming, otherwise strike first
        if gap < MELEE_GAP:
            if foe.attack_timer > 0 and r.random() < lv["block"]:
                self.press("block", 14)
                self.move = 0
                return
            if me.charge("attack") >= 1 and r.random() < lv["aggro"]:
                self.press("attack", 2)
            self.move = -toward if r.random() < 0.5 else 0     # step back to cast again
            self.unstick(me, toward)
            return

        # At range: signature spell when it makes sense, otherwise Stun Bolt
        if me.charge("spell2") >= 1 and r.random() < lv["aggro"] and self.worth_casting(kind, foe):
            self.press("spell2", 2)
        elif me.charge("spell1") >= 1 and r.random() < lv["aggro"] * 0.7:
            self.press("spell1", 2)

        # Keep to this wizard's favourite distance
        want = PREFERRED_RANGE.get(kind, 260) + r.uniform(-lv["range_slop"], lv["range_slop"])
        if distance > want + 40:
            self.move = toward
        elif distance < want - 40:
            self.move = -toward
        else:
            self.move = 0
        self.unstick(me, toward)
        if r.random() < 0.06:                                    # the odd hop keeps it lively
            self.press("jump", 3)

    def worth_casting(self, kind, foe):
        if kind == "quake":
            return foe.on_ground()          # a jumping target would dodge it
        if kind == "vines":
            return foe.slow_timer == 0      # don't waste it on someone already slowed
        return True

    def unstick(self, me, toward):
        """Backed into a wall? Stop retreating and jump instead."""
        retreating = self.move == -toward
        at_wall = me.rect.left <= 2 if self.move < 0 else me.rect.right >= self.arena_width - 2
        if retreating and at_wall:
            self.move = 0
            if self.rng.random() < 0.5:
                self.press("jump", 3)
